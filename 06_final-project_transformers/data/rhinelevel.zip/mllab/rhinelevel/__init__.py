"""Convenience API to build a training and production dataset from the
river level data and weather/climate data."""

